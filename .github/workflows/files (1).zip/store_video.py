import os
import shutil

def store_video(src_path, dest_folder="videos"):
    os.makedirs(dest_folder, exist_ok=True)
    if src_path.lower().endswith(".mp4"):
        shutil.copy(src_path, dest_folder)
        print(f"Stored {src_path} in {dest_folder}/")
    else:
        print("Not an MP4 file.")

# Usage:
# store_video("/path/to/video.mp4")