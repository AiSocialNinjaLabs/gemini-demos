import boto3

def upload_mp4_to_s3(file_path, bucket_name, object_name=None):
    s3 = boto3.client('s3')
    if not file_path.endswith('.mp4'):
        raise ValueError('File is not an MP4.')
    if object_name is None:
        object_name = os.path.basename(file_path)
    s3.upload_file(file_path, bucket_name, object_name)
    print(f"Uploaded {file_path} to s3://{bucket_name}/{object_name}")

# Usage:
# upload_mp4_to_s3('video.mp4', 'your-bucket-name')