from flask import Flask, request
import os

app = Flask(__name__)
UPLOAD_FOLDER = 'videos'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/upload', methods=['POST'])
def upload_file():
    file = request.files['file']
    if file.filename.endswith('.mp4'):
        file.save(os.path.join(UPLOAD_FOLDER, file.filename))
        return 'Video uploaded!'
    return 'Invalid file type.', 400

# To run:
# flask run